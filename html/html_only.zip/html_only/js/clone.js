$(".simprod_item").clone().appendTo(".stringsimprod");


$(".simprod_item").clone().appendTo(".addclone");
$(".simprod_item").clone().appendTo(".addclone");
$(".simprod_item").clone().appendTo(".addclone");

$(".prod_item_list").clone().appendTo(".product_list_list");
$(".prod_item_list").clone().appendTo(".product_list_list");
$(".prod_item_list").clone().appendTo(".product_list_list");
$(".prod_item_list").clone().appendTo(".product_list_list");
$(".prod_item_list").clone().appendTo(".product_list_list");

$(".basket_item").clone().appendTo(".basket_container");
$(".basket_item").clone().appendTo(".basket_container");
$(".basket_item").clone().appendTo(".basket_container");

$(".news_item").clone().appendTo(".news_wrapper_newspage");
$(".news_item").clone().appendTo(".news_wrapper_newspage");

$(".history_item").clone().appendTo(".history_items");
$(".history_item").clone().appendTo(".history_items");

